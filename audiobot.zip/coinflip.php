<?
  $b = 'https://srmcgann.github.io/assets/';
  echo $b . (rand() < getrandmax()/2 ? 'pW8Sw.png' : 'QMdhg.png');
?>
